package Laboratorio;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class CrearObjeto {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Usuario miUsuario = new Usuario("Jaime", "1234");
		System.out.println(miUsuario);
		
		try {
			ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream("user.out"));
			o.writeObject(miUsuario);
			o.close();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println();
		}
	}

}
